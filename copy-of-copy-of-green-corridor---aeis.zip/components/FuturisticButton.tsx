import React from 'react';

interface Props {
  children: React.ReactNode;
  onClick?: () => void;
  variant?: 'primary' | 'danger' | 'warning';
  className?: string;
  disabled?: boolean;
}

const FuturisticButton: React.FC<Props> = ({ 
  children, 
  onClick, 
  variant = 'primary', 
  className = '',
  disabled = false
}) => {
  const baseStyles = "relative px-6 py-3 font-mono font-bold uppercase tracking-wider transition-all duration-300 clip-path-slant group overflow-hidden border";
  
  const variants = {
    primary: "border-neon-green text-neon-green hover:bg-neon-green hover:text-black",
    danger: "border-alert-red text-alert-red hover:bg-alert-red hover:text-white",
    warning: "border-yellow-400 text-yellow-400 hover:bg-yellow-400 hover:text-black",
  };

  const disabledStyles = "opacity-50 cursor-not-allowed pointer-events-none grayscale";

  return (
    <button 
      onClick={onClick} 
      disabled={disabled}
      className={`${baseStyles} ${variants[variant]} ${disabled ? disabledStyles : ''} ${className}`}
    >
      <span className="relative z-10 flex items-center justify-center gap-2">
        {children}
      </span>
      <div className="absolute inset-0 bg-white/10 translate-y-full group-hover:translate-y-0 transition-transform duration-300 ease-out" />
    </button>
  );
};

export default FuturisticButton;
